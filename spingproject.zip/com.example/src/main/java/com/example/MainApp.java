

package com.example;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {
   public static void main(String [] args)
   {
	   Session session=HibernateUtil.getSessionFactory().openSession();
			   
	   Transaction tx=null;
	   
	   try {
		   
		   tx=session.beginTransaction();
		   Employee emp=new Employee("John Doe",30);
		   
		   session.persist(emp);
		   tx.commit();
		   System.out.println("Insert employee ID: "+emp.getId());
		   
	   }
	   catch(Exception e)
	   {
		   if(tx!=null) tx.rollback();
		   e.printStackTrace();
	   }
	   
	   finally
	   {
		   session.close();
		   HibernateUtil.shutdown();
	   }
	   
   }
}




